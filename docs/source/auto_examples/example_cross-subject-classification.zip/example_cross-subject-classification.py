"""
Example: cross subject classification
=====================================

example
"""

# import rosoku

import numpy as np


a = np.array([1, 2, 3])

b = np.array([123445])
b = np.array([123445])
b = np.array([123445])

print(a)
