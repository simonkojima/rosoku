"""
Example: cross subject classification
=====================================

example
"""

# import rosoku

import numpy as np
import matplotlib.pyplot as plt

a = np.array([1, 2, 3])


print(a)
print(a)
print(a)
print(a)

plt.plot(np.arange(1, 32))
